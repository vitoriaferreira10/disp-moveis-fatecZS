/* Criação do Database db2020*/
 
CREATE DATABASE db2020;

/* Criação da tabela Usuarios*/

CREATE TABLE db2020.usuarios (
  id BIGINT NOT NULL AUTO_INCREMENT,
  nome VARCHAR(255),
  login VARCHAR(255),
  senha VARCHAR(255),
  status VARCHAR(255),
  tipo VARCHAR(255),
  PRIMARY KEY (id));
 
/* Criação da tabela Atores*/
 
CREATE TABLE db2020.atores (
id BIGINT NOT NULL AUTO_INCREMENT,
nome VARCHAR(255),
idade BIGINT,
sexo VARCHAR(255),
PRIMARY KEY (id)
);
 
/* Criação da tabela Filmes*/
 
CREATE TABLE db2020.filmes (
id BIGINT NOT NULL AUTO_INCREMENT,
nome VARCHAR(255),
genero VARCHAR(255),
ano BIGINT,
PRIMARY KEY (id)
);
 
/* Criação da tabela atuação*/
 
CREATE TABLE db2020.atuacao (
id BIGINT NOT NULL AUTO_INCREMENT,
id_ator BIGINT,
id_filme BIGINT,
PRIMARY KEY (id)
);
 
/* Criação das chaves estrangeiras*/
 
ALTER TABLE db2020.atuacao ADD CONSTRAINT FK_ator_filme_id FOREIGN KEY (id_ator) REFERENCES db2020.atores(id);
ALTER TABLE db2020.atuacao ADD CONSTRAINT FK_filme_ator_id FOREIGN KEY (id_filme) REFERENCES db2020.filmes(id);
